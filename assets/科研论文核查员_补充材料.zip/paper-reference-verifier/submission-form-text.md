# 腾讯问卷填写内容（可直接复制）

## 项目名称
科研论文核查员（Paper Reference Verifier）

## 项目方向
AI Agent（04）；应用场景以生物医学 / 健康类稿件为主，方法可迁移到任意学科

## 项目简介、科学问题与使用场景

【痛点】大模型进入写作流程后，引用失实被迅速放大：DOI 看似合法却不存在；DOI 真实但年份、作者、期刊、卷期页被张冠李戴；已撤稿论文仍被当作有效证据；报告 p 值与原始数据矛盾。人工逐条点开核对极耗时，通用模型“凭记忆”又分不清“不著名但真实”与“格式合法但伪造”——离线实测幻觉 DOI 检测 F1 仅 0.62，三项任务合计 23 次误报。

【做法】在 SciencePal 沙箱内构建核查 Agent：每条引用强制实际联网请求 Crossref，以真实 HTTP 200/404 判定存在性；对返回元数据逐字段严格比对；检查撤稿标题标记与 relation 撤稿关系；必要时在沙箱安装 scipy 复算统计量。所有结论附可点击证据 URL、HTTP 状态与复算脚本，输出中文报告加固定 schema 的 JSON。输入可以是一篇 PDF、一组 DOI 或一份参考文献清单，单次核查 12–36 条，逐条给出 DOI 状态、题录一致性、撤稿与统计问题，并给出总体风险评级。

【技术亮点】1) 强制取证，禁止凭记忆作答；2) 可复现金标准：评测集由脚本从 Crossref 实时构造，构造时即校验 404，并用 SSE 联网审计确保对照组公平；3) 代码级 guardrail：运行时拦截写记忆、反问等越权工具调用，强制“结构/覆盖/证据/自洽”四类交付契约校验，失败自动修复并留痕——稿件是不可信输入，提示词层的软约束挡不住。

【目标用户】期刊编辑与审稿人、研究生与论文作者、课题组与科研管理部门。

【使用场景】投稿前逐条自检参考文献；审稿时核验引用；一批稿件初筛高风险引用；结题材料与文献库清理。

【验证】48 条金标准、三方对照：离线 F1 0.62，联网后 1.000、误报 0；换 deepseek-v4-pro 复现 4/4；真实已发表论文的 50 条书目检出 4/4、误报 0；35 个 run 的契约回溯审计中专家流程 5/5 交付合规、普通联网 Agent 2/4；6 例稿件注入下交付可用率 4/6 提升到 6/6。

【价值】把“凭记忆判断”换成“可复核证据”，让论文核查可规模化、可审计、可复现。对期刊，可把引用核查从抽检变为全检；对作者，投稿前消除致命小错；对机构，结题与成果汇编可做合规检查。全流程在公开分享链接中免登录可回放。

> 字符数：约 1050（上限 1500）。若需更短，删掉【技术亮点】第 2 点与【价值】最后一句即可压到约 800。


---

## SciencePal 作品链接

主演示（推荐，4 条引用覆盖 4 种状态）：
https://sciencepal.ai/share/ee4068d7-07e5-4a27-9af7-1f3c50fedcaa

案例 A · 撤稿识别（STAP，定位官方撤稿通知）：
https://sciencepal.ai/share/f6f8746c-3350-48f1-ac58-d0150e135ac1

案例 B · 统计复算（scipy 复算，p 值与数据矛盾）：
https://sciencepal.ai/share/8de1f3cc-cde0-41ad-a2b5-b3b9af5a004b

访问权限：三条均为**公开分享、免登录只读回放**，评审无需账号或授权。
如需在评审期以可写方式实际运行，可按下方说明通过组委会联系我们临时开放。

## 核心使用环节与运行说明

【SciencePal 承担的核心工作】
不是用来写文案或做 PPT：每次取证都在 SciencePal 沙箱里真实执行（execute_command 请求 Crossref，必要时装 scipy 复算），平台负责工具编排、SSE 运行记录与回放；核查流程固化在 Agent 与代码级 guardrail 中（拦截越权工具、强制交付契约校验）。

【启动步骤】
路径一（零门槛）：打开主演示链接，点「跳到结尾」直接看最终报告，点「开始播放」按真实时间回放完整 39 步轨迹，每条沙箱命令与 HTTP 状态都可见，无需登录。
路径二（亲自运行）：新建对话 → 选 Agent「科研论文核查员」（agent_id: b5834007-2e4a-4c08-b9de-c4707c31e136）→ 粘贴下方示例 → 发送。4 条约 1 分钟，12 条约 1–3 分钟。

【示例输入】
[1] Lo C., Lee C., Huang W. (2020). Prognosis of Bearing and Gear Wears Using Convolutional Neural Network with Hybrid Loss Function. Sensors, 20, 12, 3539. doi: 10.3390/s20123539
[2] Tekcan Sanli DE., Sanli AN. (2025). Comment on “Breast lymphoma: Imaging features, clinical presentation, and ultrasound AI decision support”. Clinical Imaging, 127, 110621. doi: 10.1016/j.clinimag.2025.116202
[3] Rahimian P., Mihalyi BM., Toka L. (2027). In-game soccer outcome prediction with offline reinforcement learning. Machine Learning, 113, 10, 7393-7419. doi: 10.1007/s10994-024-06611-1
[4] Obokata H, Wakayama T, Sasai Y, et al. (2014). Stimulus-triggered fate conversion of somatic cells into pluripotency. Nature, 505, 641-647. doi: 10.1038/nature12968

【预期输出】
逐条判定表（DOI 200/404、题录逐字段一致性、是否撤稿、证据 URL）+ 总体风险评级 + 末尾固定 schema 的机器可读 JSON。上述四条应依次得到：放行 / DOI 不存在 / 年份错配（Crossref 为 2024，引用写 2027）/ 已撤稿（STAP，标题带 RETRACTED）。无法确证者标 suspect 并提示人工复核。

【访问权限】
三个链接均为「免登录、只读回放」，无需评审账号或额外授权。若需在评审期以可写方式实际运行该 Agent，请通过组委会联系我们临时开放（此处不填写任何账号、密码或 API Key）。

> 字符数：约 1424（上限 1500）。


---

## 演示视频链接（3–5 分钟）

**待上传**：`assets/科研论文核查员_演示视频.mp4`（1920×1080 / 30fps / **3 分 06 秒** / 10.6 MB / 无声，画面自带文字说明）。

上传后把「仅持链接可访问」的地址填进表单，示例格式：
```
https://<你的网盘或视频站分享地址>
```

**建议的分享方式（三选一，均满足"仅持链接访问"）**
- 腾讯微云 / 百度网盘：上传 → 生成分享链接 → 设「任何人可见 / 有链接即可访问」，需要时附提取码；
- Google Drive：上传 → 共享 → 「知道链接的任何人」→ 复制链接；
- YouTube / Bilibili：不公开（Unlisted / 仅链接可见）上传，复制视频页地址。

**注意**：务必上传**新版**（3:06、约 10.6 MB）。旧版是 3:13、18 MB，其第 9 幕仍是"过程指标 8.3 vs 12.4"的旧叙事，与新 PPT 不一致。

---

## 上传项目说明（≤5 页 PDF）

**文件**：`assets/科研论文核查员_项目说明.pdf`（5 页、16:9、533 KB，由 PPT 直接导出，无缺字体）

内容覆盖官方要求：
| 要求 | 落在哪一页 |
|---|---|
| 技术方案 | 第 3 页「三层核查 + 证据留痕」，含 SciencePal 作用说明条 |
| 创新点 | 第 2–3 页（问题定义 + 工作流/代码级约束） |
| 验证结果 | 第 4 页（F1 0.62→1.0、注入 4/6→6/6、18/18 故障注入、35 run 审计） |
| 局限 | 第 4 页底部「局限」行 |
| 后续计划 | 第 5 页「未来工作」 |
| SciencePal 作用 | 第 3 页底部说明条 + 第 5 页公开回放 |


---

## 12. 资源使用声明（表格：资源名称/版本—来源链接—用途—许可或授权依据）

| 资源名称 / 版本 | 来源链接 | 在作品中的用途 | 许可或授权依据 |
|---|---|---|---|
| SciencePal 平台（2026 在线服务） | https://sciencepal.ai | Agent 运行环境、可联网沙箱、工具编排、运行记录与公开回放 | 主办方提供，按平台服务条款与赛事规则使用 |
| 大语言模型 deepseek-v4-flash（平台自动路由；另有 v4-pro 仅见于平台可选） | 由 SciencePal 平台提供，无独立外链 | 核查 Agent 的推理、离线基线对照 | 平台内调用，遵守平台模型使用条款 |
| Crossref REST API（v1，2026-10 访问） | https://api.crossref.org | DOI 存在性（HTTP 200/404）与题录元数据核验；评测集金标准实时构造 | 公开元数据接口，按 Crossref 使用条款（REST API 条款）并附 User-Agent |
| OpenAlex API（2026-10 访问） | https://api.openalex.org | 冷门撤稿案例的一次性筛选（用于 Layer-2 案例 C） | 公开开放数据，按 OpenAlex 条款（CC0 元数据） |
| scipy 1.15.3 | https://scipy.org | 核查 Agent 在沙箱内临时安装，用于统计量复算（t 检验、ANOVA、功效） | BSD-3-Clause |
| Python 3.11+（实测 3.14） | https://www.python.org | 评测、审计、guardrail 与绘图脚本的运行环境 | PSF License |
| httpx 0.28.1 | https://www.python-httpx.org | 调用 SciencePal HTTP API、读取 SSE 事件流 | BSD-3-Clause |
| matplotlib（仅制作材料） | https://matplotlib.org | 生成对照图与时间线图（不参与核查逻辑） | PSF-based / BSD 兼容 |
| python-pptx（仅制作材料） | https://python-pptx.readthedocs.io | 生成 5 页项目说明 PPT/PDF | MIT |
| 付费全文数据库 / 商业文献库 | 无 | 无 | 无 |
| 未公开数据 / 个人隐私数据 | 无 | 无 | 无 |

> 说明：全部评测数据为 Crossref/OpenAlex 公开元数据；不涉及付费全文、不包含个人信息；不填写任何密钥。

## 13. 是否基于赛前已有成果？

**建议填：否，本次赛事期间新建。**

依据：仓库首个提交为 2026-10-25 13:58（赛事期内），此前不存在本项目的代码、数据或评测集。若团队在报名前确有任何脚手架、笔记或原型，请改选"是"并在下一栏如实说明（官方明确"不因选择是先取消资格"）。

## 14. 既有成果与本次新增工作（选"是"时填写，≤2000 字符）

> 若第 13 项填"否"，此栏通常不出现或填"不适用"。若填"是"，可直接用下面这段改写：

既有部分：[逐项列出现成内容，例如某开源脚手架 / 既有提示词 / 既有数据集]，归属与授权：[团队自有 / 某开源许可及链接]。
本次新增：① 核查工作流（C1–C4 引用与出版状态、M1–M5 方法学）与"禁止凭记忆、必须联网取证"约束；② 可从 Crossref 实时重建的 48 条金标准与三方对照协议（离线基线 / 普通联网 Agent / 专家工作流）；③ SSE 联网审计方法；④ 代码级 guardrail（运行时拦截 + 四类交付契约 + 有界自动修复）与 17 条离线断言、18 例故障注入；⑤ Layer-2 撤稿与统计复算案例及同输入对照；⑥ 全部提交材料与公开回放链接。
可核对：提交表中的公开分享链接与代码仓库。

## 15. 团队分工（≤1000 字符，不向评委提供姓名，用队员 A/B）

队员 A：Agent 设计与系统提示词（C1–C4 引用核查、M1–M5 方法学审查）；评测基准构造（Crossref 实时生成、404 校验）；三方对照跑批与 SSE 联网审计；代码级 guardrail 实现与离线断言、故障注入；指标计算与技术报告撰写。

队员 B：Layer-2 案例设计（撤稿识别、统计复算）；结果复核与数据校验（逐条比对、混淆项排查）；5 页项目说明、演示视频与旁白脚本；提交材料整理、公开链接与合规检查（声明、资源清单）。

共同：选题与结论讨论；对外演示与答辩准备。分工按实际承担划分，非按工作量均分。

## 16. 补充材料链接（选填，按"材料名称＋链接＋访问说明"）

1. 代码仓库（公开，无需登录）：https://github.com/medisean/sciencepal-paper-verifier
   —— 含评测集构造、三方跑批、评分、审计、guardrail、CLI 全部脚本。
2. 技术报告（仓库内）：`results/TECHNICAL_REPORT.md`
   —— 方法、三方对照、SSE 审计、guardrail 协议、局限与后续计划。
3. 可复现实验材料（仓库内）：`results/guardrail/PROTOCOL.md`、`results/guardrail/SUMMARY.md`、`results/guardrail/CONTRACT_AUDIT.md`
   —— 含 35 个 run 的契约回溯审计与 18 例故障注入结果。
4. Agent 配置说明（仓库内）：`scripts/update_verifier_prompt.py`、`scripts/add_verifier_c4.py`
   —— 系统提示词与撤稿检查的幂等下发脚本；平台侧 Agent 为私有，如需评审期直接运行可联系我方临时开放。
5. 结果图：`results/figures/guardrail_timeline.png`（真实拦截时间线）、`results/figures/guardrail_compare.png`（干预前后对照）。
6. 用户测试记录：**暂无**（如明天补充，填：`results/usability.md`，含 3 位受试者的耗时与检出记录）。

## 17. 补充材料文件（1 个 ZIP 或 PDF，≤50MB）

**文件**：`assets/科研论文核查员_补充材料.zip`（**1.17 MB**，120 个条目，UTF-8 文件名）

内容：README 与复现说明、技术报告、guardrail 协议与审计、Layer-2 案例、金标准评测集（48 条 + 对抗注入 + 36 条规模集）、全部脚本、5 页说明 PDF/PPTX、原创性与资源使用声明、视频旁白脚本。
**不含**：`.env` 与任何 API Key、`output/` 原始 SSE（可由脚本重新生成）、视频文件（第 10 项单独提供链接）。

> 解压后根目录为 `paper-reference-verifier/`，`00_README_补充材料说明.md` 是导览。
